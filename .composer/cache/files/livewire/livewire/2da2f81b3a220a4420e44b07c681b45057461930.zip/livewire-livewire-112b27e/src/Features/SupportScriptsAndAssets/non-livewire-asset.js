
document.querySelector('[dusk="foo"]').textContent = 'non livewire evaluated'
