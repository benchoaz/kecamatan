<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportPageComponents\BaseTitle;

#[\Attribute]
class Title extends BaseTitle
{
    //
}
